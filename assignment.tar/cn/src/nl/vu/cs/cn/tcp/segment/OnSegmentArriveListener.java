package nl.vu.cs.cn.tcp.segment;

public interface OnSegmentArriveListener {

    public void onSegmentArrive(Segment segment);
}
