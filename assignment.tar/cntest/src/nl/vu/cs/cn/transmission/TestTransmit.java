package nl.vu.cs.cn.transmission;


/**
 * This class ...
 *
 * @author Jeffrey Klardie
 */
public class TestTransmit extends TestTransmitBase {

    public void testTransmit() throws Exception {
        doNormalTransmissionTest();
    }
}
